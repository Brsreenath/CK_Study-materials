foo = " \t Hello Oracle \n \n "

print "Welcome to python 2.7 example"

print 'Result ' + foo

foo.strip()



